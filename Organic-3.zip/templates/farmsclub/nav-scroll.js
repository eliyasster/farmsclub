/* Makes any [data-sitenav] bar sit transparent (gradient scrim, light text) over
   the hero, then turn solid once the first fold has scrolled past. Purely
   imperative so the page paints correctly before this runs. */
(() => {
  if (window.__farmsclubNav) return; window.__farmsclubNav = true;
  const apply = () => {
    document.querySelectorAll('[data-sitenav]').forEach((n) => {
      const solid = window.scrollY > Math.max(60, window.innerHeight * 0.8 - n.offsetHeight - 8);
      n.style.background = solid
        ? 'color-mix(in srgb, var(--color-bg) 92%, transparent)'
        : 'linear-gradient(to bottom, rgba(28,26,22,.58), rgba(28,26,22,.18) 60%, rgba(28,26,22,0))';
      n.style.backdropFilter = solid ? 'blur(10px)' : 'none';
      n.style.boxShadow = solid ? '0 1px 0 color-mix(in srgb, var(--color-text) 12%, transparent)' : 'none';
      n.querySelectorAll('a').forEach((a) => { a.style.color = solid ? '' : '#fff'; });
      /* The logo reads these two custom properties, so it opens big and light
         over the hero and shrinks to dark ink once the bar goes solid. Set on
         the nav (not the img) because the markup is React-owned. */
      n.toggleAttribute('data-solid', solid);
      /* Keyed on the image itself: the DC runtime does not recompute descendant
         styles when an ancestor attribute changes, so ancestor-keyed rules never
         land. setProperty with priority also beats the template's style attr. */
      n.querySelectorAll('[data-fc-logo]').forEach((img) => {
        img.toggleAttribute('data-fc-small', solid);
        img.style.setProperty('height', solid ? 'clamp(24px,2.4vw,30px)' : 'clamp(38px,4.4vw,54px)', 'important');
        img.style.setProperty('filter', solid ? 'none' : 'brightness(0) invert(1)', 'important');
      });
      /* language pill follows the bar's ink */
      n.querySelectorAll('[data-fc-lang-btn]').forEach((b) => {
        b.__solid = solid;
        b.style.borderColor = solid ? 'color-mix(in srgb, var(--color-text) 30%, transparent)' : 'rgba(255,255,255,.55)';
        b.style.background = solid ? 'transparent' : 'rgba(255,255,255,.1)';
        b.style.color = solid ? 'var(--color-text)' : '#fff';
      });
    });
  };
  addEventListener('scroll', apply, { passive: true });
  addEventListener('resize', apply);
  apply();
  const t = setInterval(apply, 250);
  setTimeout(() => clearInterval(t), 6000);
})();
